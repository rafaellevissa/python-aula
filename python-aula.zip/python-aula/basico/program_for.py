for i in range(0,100):
	print(i)