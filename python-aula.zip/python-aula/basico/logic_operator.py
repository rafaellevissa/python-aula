# Definindo algumas variáveis booleanas
a: bool = True
b: bool = False
c: bool = True

# Usando o conectivo lógico 'and'
print("a and b:", a and b)  # Deve ser False, pois b é False
print("a and c:", a and c)  # Deve ser True, pois ambos a e c são True

# Usando o conectivo lógico 'or'
print("a or b:", a or b)   # Deve ser True, pois a é True
print("b or c:", b or c)   # Deve ser True, pois c é True

# Usando o conectivo lógico 'not'
print("not a:", not a)     # Deve ser False, pois a é True
print("not b:", not b)     # Deve ser True, pois b é False
