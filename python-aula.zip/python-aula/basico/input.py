print ("digite um valor: ");
a=input(); #leitura de dados
print(a);

