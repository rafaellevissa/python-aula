# Definindo algumas variáveis numéricas
x: int = 2
y: int = 3

# Adição
print("Adição (x + y):", x + y)  # Resultado: 13

# Subtração
print("Subtração (x - y):", x - y)  # Resultado: 7

# Multiplicação
print("Multiplicação (x * y):", x * y)  # Resultado: 30

# Divisão
print("Divisão (x / y):", x / y)  # Resultado: Aproximadamente 3.3333

# Divisão Inteira
print("Divisão Inteira (x // y):", x // y)  # Resultado: 3

# Módulo
print("Módulo (x % y):", x % y)  # Resultado: 1 (resto da divisão de 10 por 3)

# Exponenciação
print("Exponenciação (x ** y):", x ** y)  # Resultado: 1000 (10 elevado a 3)
