# Números: Inteiros e de ponto flutuante
numero_inteiro: int = 42
numero_float: float = 3.14

# Texto: String
texto: str = "Olá, mundo!"

# Lista: Coleção ordenada e mutável
# A lista é heterogênea, então usamos 'list' genérico
minha_lista: list = [1, 2, 3, "Python", numero_float]

# Tupla: Coleção ordenada e imutável
# Tuplas heterogêneas são anotadas com cada tipo de elemento
minha_tupla: tuple = (4, 5, 6, "Programação")

# Dicionário: Coleção desordenada de pares chave-valor
meu_dicionario: dict[str, int | str] = {"nome": "Alice", "idade": 30, "linguagem": "Python"}

# Conjunto: Coleção não ordenada e sem elementos duplicados
meu_conjunto: set = {1, 2, 3, 4, 5}

# Booleanos: Verdadeiro ou Falso
verdadeiro: bool = True
falso: bool = False

# NoneType: Representa a ausência de valor
sem_valor: None = None

# Exibindo todos os tipos de dados
print("Número inteiro:", numero_inteiro)
print("Número de ponto flutuante:", numero_float)
print("String:", texto)
print("Lista:", minha_lista)
print("Tupla:", minha_tupla)
print("Dicionário:", meu_dicionario)
print("Conjunto:", meu_conjunto)
print("Booleano (verdadeiro):", verdadeiro)
print("Booleano (falso):", falso)
print("NoneType:", sem_valor)
