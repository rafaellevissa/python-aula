def funcao(valor: int)-> int:
	valor=valor+10	
	return valor

print(funcao(2))