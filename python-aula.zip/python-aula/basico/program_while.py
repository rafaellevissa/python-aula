item=1 
lista=[]
print(lista)
while item<=10:
	lista.append(item)
	item=item+1
print(lista)
