#!/usr/bin/python3
print("Programa if");
v= input("Digite um numero inteiro\n");
if (int(v)>5):
	print("o numero digitado e maior que 5");
elif (int(v)<5):
	print("o numero e menor que 5");
else:
	print("o numero e 5");
