nome= "Levi"
intervalo=nome[2:4]
print(intervalo)
