preco=50.75789
print("o valor total %.2f"%preco)
