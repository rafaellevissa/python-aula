##Curso
##Adicionar as disciplinas por semestre
##Editar
##Ver os semestres
print("Criador de grade curricular")
curso = input("Digite o curso:\n")
matgeral = ['2',[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]
a = []
while True:
    print("\nGrade Curricular do curso: %s \n"%curso)
    op = int(input("Escolha uma opcao: \n1)Adicionar disciplina\n2)Exibir grade por semestre\n3)Exibir grade completa\n4)Sair\n"))
    def grade(sem, mat):
        a = matgeral[sem]
        a.extend(mat)
        return matgeral
    if op == 1:
        semestre = int(input("Digite o semestre:\n"))
        n = ""
        materias = []
        while n != '-1':
            n = input("Digite a materia: (caso deseje sair digite -1)\n")
            if n != '-1':
                materias.append(n)
        grade(semestre,materias)
    if op == 2:
        num = int(input("Digite o semestre a ser exibido: \n"))
        b = matgeral[num]
        print ("Materias do %dº semestre:\n" %num)
        for i in b:
            print(i)
    if op == 3:
        print ("Grade Completa:\n")
        for i in matgeral:
            if i != '2' and i != []:
                m = matgeral.index(i)
                print ("\n%dº semestre" %m)
                for p in i:
                    print(p)
    if op == 4:
        print ("Bjs tchau")
        break
        
                       
            
##    
##puxar a lista que tem o index do semestre e dar um extend com nossa nova lista
