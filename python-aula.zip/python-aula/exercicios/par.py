print("verifica numero par")
n=int(input("digite um numero: "))
if(n%2==0):
	print("par")
else:
	print("impar")
