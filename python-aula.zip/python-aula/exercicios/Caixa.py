print("Bem-vindo ao Caixa!\n")
d=0
p=0
soma=0
while(d!=3):
    print("Menu")
    print("Digite um numero de 1 a 3")
    print("1- Consultar o produto")
    print("2- Registrar o produto")
    print("3- Sair")
    d=int(input())
    if(d==1):
        print("1.Banana - R$5.00 | 2.Agua - R$2.00 | 3.Leite - R$3.50 | 4.Pao - R$1.50\n")
    elif(d==2):
        while (p!=0 and p!=999):
            print("Digite o codigo do produto")
            print("Digite 999 para voltar ao menu")
            print("Digite 0 para somar e finalizar")
            p=int(input())
            if(p==1):
                print("Banana = R$5.00\n")
            elif(p==2):
                print("Agua = R$2.00\n")
            elif(p==3):
                print("Leite = R$3.50\n")
            elif(p==4):
                print("Pao = R$1.50\n")
            elif(p==0):
                print("Caixa Registrado e somado\n")
            elif(p==999):
                print("Registro cancelado\n")
            else:
                print("Por favor digite um codigo valido\n")
    elif(d==3):
        print("Muito obrigado pela sua compra")
    else:
        print("Opcao Invalida, por favor digite um numer de 1 a 3")
        
            
