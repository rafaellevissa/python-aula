print("programa de calculo de media")
op=0
while (op!=3):
	print("Menu:")
	print("1- Digitar notas")
	print("2- Exibir media")
	print("3- sair")
	op=int(input())
	if(op==1):
		soma=float(0)
		n=float(0)
		i=0
		media=float(0)
		while (n!=-1):
			n=float(input("digite a nota %d (-1 para sair): \n"%i))
			if(n!=-1):
				i=i+1
				soma=soma+n
					
	elif(op==2):
		media=soma/i	
		print("media = %.2f" %media)
	elif(op==3):
		print("obrigado por utilizar esse programa!")	
	else:
		print("opcao invalida")
