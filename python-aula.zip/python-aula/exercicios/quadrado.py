def quadrado(valor: int) -> int:
	valor=valor**2
	print("resultado: %d"%valor)	
	return valor

quadrado(3)