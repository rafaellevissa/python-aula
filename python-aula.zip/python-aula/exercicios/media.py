print("pragrama da media")
print("digite a primeira nota")
n1=input()
print("digite a segunda nota")
n2=input()
print("digite a terceira nota")
n3=input()
media=(int(n1)+int(n2)+int(n3))/3
print("media: %d"%media)
