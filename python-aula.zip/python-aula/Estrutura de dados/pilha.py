# Pilhas são estruturas de dados que seguem o princípio de Último a Entrar, 
# Primeiro a Sair (LIFO - Last In, First Out). Em Python, uma pilha pode ser 
# facilmente implementada usando uma lista, onde o final da lista é o topo da pilha. 
# Vamos criar uma classe Pilha para demonstrar os conceitos básicos de uma pilha, incluindo 
# operações como empilhar (push), desempilhar (pop) e verificar o elemento no topo.

class Pilha:
    def __init__(self):
        self.itens = []

    def empilhar(self, item):
        self.itens.append(item)

    def desempilhar(self):
        if not self.vazia():
            return self.itens.pop()
        else:
            print("A pilha está vazia.")
            return None

    def topo(self):
        if not self.vazia():
            return self.itens[-1]
        else:
            print("A pilha está vazia.")
            return None

    def vazia(self):
        return len(self.itens) == 0

    def tamanho(self):
        return len(self.itens)

# Testando a classe Pilha
pilha = Pilha()
pilha.empilhar(1)
pilha.empilhar(2)
pilha.empilhar(3)

print("Elemento no topo:", pilha.topo())
print("Tamanho da pilha:", pilha.tamanho())

print("Desempilhando:", pilha.desempilhar())
print("Novo topo:", pilha.topo())
print("Tamanho da pilha:", pilha.tamanho())


# Neste código:

# A classe Pilha usa uma lista interna (self.itens) para armazenar os elementos.
# O método empilhar adiciona um elemento ao topo da pilha.
# O método desempilhar remove e retorna o elemento do topo da pilha.
# O método topo retorna o elemento do topo da pilha sem removê-lo.
# O método vazia verifica se a pilha está vazia.
# O método tamanho retorna o número de elementos na pilha.