# Uma heap (ou monte binário) é uma árvore binária especial onde cada nó
#  pai é maior (ou menor, dependendo do tipo de heap) que seus nós filhos.
#   O tipo mais comum é a heap máxima, onde o valor de cada nó pai é maior 
#   que o de seus filhos. Heaps são úteis para operações como encontrar o maior
#    (ou menor) elemento, e são frequentemente usadas em algoritmos de ordenação,
#     como heapsort.

# Em Python, podemos usar a biblioteca heapq para implementar uma heap. 
# Vou demonstrar como criar uma heap mínima, que mantém o menor elemento como a raiz da árvore.

import heapq

class MinHeap:
    def __init__(self):
        self.heap = []

    def inserir(self, item):
        heapq.heappush(self.heap, item)

    def remover_minimo(self):
        if self.heap:
            return heapq.heappop(self.heap)
        else:
            print("A heap está vazia.")
            return None

    def obter_minimo(self):
        if self.heap:
            return self.heap[0]
        else:
            print("A heap está vazia.")
            return None

# Testando a MinHeap
min_heap = MinHeap()
min_heap.inserir(12)
min_heap.inserir(3)
min_heap.inserir(5)

print("Elemento mínimo:", min_heap.obter_minimo())
print("Removendo elemento mínimo:", min_heap.remover_minimo())
print("Novo elemento mínimo:", min_heap.obter_minimo())


# Neste código:

# MinHeap é uma classe que representa uma heap mínima. Ela usa uma lista (self.heap) para armazenar os elementos da heap.
# inserir adiciona um novo item à heap e mantém a propriedade da heap mínima.
# remover_minimo remove e retorna o menor elemento da heap.
# obter_minimo retorna o menor elemento sem removê-lo.