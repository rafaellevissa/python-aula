# Listas em Python são estruturas de dados versáteis que podem ser usadas
#  para armazenar uma coleção de itens. Elas são dinâmicas, o que significa
#   que podem crescer e diminuir de tamanho conforme necessário, e podem conter 
#   itens de tipos diferentes. Vou criar um exemplo que demonstra várias operações
#    comuns com listas, incluindo adicionar, remover e acessar elementos, além de 
#    outras funcionalidades úteis das listas em Python.

# Criando uma lista
minha_lista = [1, 2, 3, 4, 5]

# Adicionando elementos
minha_lista.append(6)  # Adiciona ao final da lista
minha_lista.insert(0, 0)  # Insere o elemento 0 na posição 0

# Acessando elementos
primeiro_elemento = minha_lista[0]
ultimo_elemento = minha_lista[-1]

# Removendo elementos
minha_lista.remove(3)  # Remove o primeiro elemento com o valor 3
elemento_removido = minha_lista.pop(1)  # Remove e retorna o elemento na posição 1

# Outras operações comuns
tamanho_da_lista = len(minha_lista)  # Obtém o tamanho da lista
minha_lista.reverse()  # Inverte a lista

# List comprehensions para transformação de listas
quadrados = [x ** 2 for x in minha_lista]

# Imprimindo resultados
print("Lista:", minha_lista)
print("Primeiro elemento:", primeiro_elemento)
print("Último elemento:", ultimo_elemento)
print("Elemento removido:", elemento_removido)
print("Tamanho da lista após remoções:", tamanho_da_lista)
print("Lista de quadrados:", quadrados)


# Neste código:

# A lista é inicializada com alguns elementos.
# São demonstradas as operações de adição (append e insert), acesso (por índice) e remoção (remove e pop) de elementos.
# O tamanho da lista é obtido com len.
# A lista é invertida com reverse.
# Uma list comprehension é usada para criar uma nova lista (quadrados), contendo o quadrado de cada elemento da lista original.