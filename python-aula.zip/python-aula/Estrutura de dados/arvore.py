# Árvores são uma estrutura de dados fundamental em ciência da computação, 
# utilizadas para representar hierarquias e relações de parentesco. Uma árvore 
# consiste em nós conectados por arestas, com um único nó raiz a partir do qual 
# todos os outros nós são acessíveis.

class No:
    def __init__(self, valor):
        self.valor = valor
        self.esquerda = None
        self.direita = None

class ArvoreBinaria:
    def __init__(self, raiz):
        self.raiz = No(raiz)

    def inserir(self, valor, no_atual):
        if valor < no_atual.valor:
            if no_atual.esquerda is None:
                no_atual.esquerda = No(valor)
            else:
                self.inserir(valor, no_atual.esquerda)
        else:
            if no_atual.direita is None:
                no_atual.direita = No(valor)
            else:
                self.inserir(valor, no_atual.direita)

    def imprimir_em_ordem(self, no_atual):
        if no_atual is not None:
            self.imprimir_em_ordem(no_atual.esquerda)
            print(no_atual.valor, end=' ')
            self.imprimir_em_ordem(no_atual.direita)

# Testando a árvore binária
arvore = ArvoreBinaria(10)
arvore.inserir(6, arvore.raiz)
arvore.inserir(14, arvore.raiz)
arvore.inserir(3, arvore.raiz)
arvore.inserir(8, arvore.raiz)
arvore.inserir(12, arvore.raiz)
arvore.inserir(16, arvore.raiz)

print("Árvore Binária em Ordem:")
arvore.imprimir_em_ordem(arvore.raiz)


# Neste código:

# No é uma classe que representa um único nó na árvore. Cada nó armazena um valor e tem referências para seus nós filho à esquerda e à direita.
# ArvoreBinaria é uma classe que representa a árvore binária. Ela começa com um nó raiz e possui métodos para inserir novos valores e imprimir a árvore.
# O método inserir coloca novos valores na árvore. Se o valor for menor que o do nó atual, ele vai para a esquerda; se for maior, vai para a direita.
# O método imprimir_em_ordem percorre a árvore e imprime os valores em ordem ascendente (percurso em ordem).