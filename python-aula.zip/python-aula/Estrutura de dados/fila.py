# Uma fila é uma estrutura de dados linear que segue a ordem de Primeiro a Entrar, 
# Primeiro a Sair (FIFO - First In, First Out). Em Python, podemos implementar uma
#  fila usando listas ou a classe deque da biblioteca collections, que é mais eficiente
#   para adicionar e remover elementos das extremidades da fila.


from collections import deque

class Fila:
    def __init__(self):
        self.fila = deque()

    def entrar(self, item):
        self.fila.append(item)

    def sair(self):
        if self.vazia():
            print("A fila está vazia, não é possível remover um elemento.")
        else:
            return self.fila.popleft()

    def tamanho(self):
        return len(self.fila)

    def vazia(self):
        return len(self.fila) == 0

    def frente(self):
        if self.vazia():
            print("A fila está vazia.")
        else:
            return self.fila[0]

# Testando a classe Fila
fila = Fila()
fila.entrar(1)
fila.entrar(2)
fila.entrar(3)

print("Primeiro da fila:", fila.frente())
print("Tamanho da fila:", fila.tamanho())

print("Removendo elemento:", fila.sair())
print("Novo primeiro da fila:", fila.frente())
print("Tamanho da fila:", fila.tamanho())


# Neste código:

# A classe Fila é criada com uma instância de deque.
# entrar adiciona um item ao final da fila.
# sair remove um item do início da fila e retorna esse item.
# tamanho retorna o número de itens na fila.
# vazia verifica se a fila está vazia.
# frente retorna o primeiro item da fila sem removê-lo.