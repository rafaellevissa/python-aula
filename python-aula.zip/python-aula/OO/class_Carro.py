#definindo a classe carro
class Carro(object):
	cor=None
	n_rodas=None
	def __init__(self, cor_carro, n_rodas_carro):
		self.cor=cor_carro
		self.n_rodas=n_rodas_carro
		pass
	def get_cor(self):		
		return self.cor
	def get_n_rodas(self):
		return self.n_rodas
	def escreva(self):
		print("%d"%self.n_rodas)
		print("%s"%self.cor)

c = Carro("Amarelo", 4)
c.escreva()