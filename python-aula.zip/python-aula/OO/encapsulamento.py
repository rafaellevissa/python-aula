class ContaBancaria:
    def __init__(self, saldo_inicial: float) -> None:
        self.__saldo: float = saldo_inicial

    def depositar(self, quantia: float) -> None:
        if quantia > 0:
            self.__saldo += quantia
            print(f"Depositado: {quantia}. Saldo atual: {self.__saldo}")
        else:
            print("A quantia de depósito deve ser positiva.")

    def sacar(self, quantia: float) -> bool:
        if 0 < quantia <= self.__saldo:
            self.__saldo -= quantia
            print(f"Sacado: {quantia}. Saldo atual: {self.__saldo}")
            return True
        else:
            print("Quantia de saque inválida.")
            return False

    def obter_saldo(self) -> float:
        return self.__saldo

# Testando a classe
conta = ContaBancaria(1000.0)
conta.depositar(500.0)
conta.sacar(200.0)
print("Saldo final:", conta.obter_saldo())
