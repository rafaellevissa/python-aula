class Student:
    __schoolName: str = 'XYZ School'  # private class attribute

    def __init__(self, name: str, age: int) -> None:
        self.__name: str = name   # private instance attribute
        self.__age: int = age     # private instance attribute

    def __display(self) -> None:  # private method
        print('This is a private method.')

std = Student("Bill", 25)

# Acesso e modificação de atributos privados via name mangling
print(std._Student__name)  # 'Bill'

std._Student__name = 'Steve'
print(std._Student__name)  # 'Steve'

# Chamando um método privado
std._Student__display()  # 'This is a private method.'
