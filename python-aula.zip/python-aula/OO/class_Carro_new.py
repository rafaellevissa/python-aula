#definindo a classe carro
class Carro:
    def __init__(self, cor_carro: str, n_rodas_carro: int) -> None:
        self.cor: str = cor_carro
        self.n_rodas: int = n_rodas_carro

    def get_cor(self) -> str:     
        return self.cor

    def get_n_rodas(self) -> int:
        return self.n_rodas

    def escreva(self) -> None:
        print(f"{self.n_rodas}")
        print(f"{self.cor}")

c = Carro("Amarelo", 4)
#print(c.get_cor())
c.escreva()