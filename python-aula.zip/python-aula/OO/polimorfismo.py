class Veiculo:
    def mover(self):
        raise NotImplementedError("O método mover deve ser implementado pela subclasse.")

class Carro(Veiculo):
    def mover(self):
        print("O carro está se movendo.")

class Barco(Veiculo):
    def mover(self):
        print("O barco está navegando.")

class Aviao(Veiculo):
    def mover(self):
        print("O avião está voando.")

def iniciar_movimento(veiculo):
    veiculo.mover()

# Testando polimorfismo
carro = Carro()
barco = Barco()
aviao = Aviao()

iniciar_movimento(carro)
iniciar_movimento(barco)
iniciar_movimento(aviao)
