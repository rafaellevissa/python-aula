def saudacao(nome: str, mensagem: str = "Olá", repeticao: int = 1) -> None:
    for _ in range(repeticao):
        print(f"{mensagem}, {nome}!")

# Chamando a função com diferentes números de argumentos
saudacao("Maria")
saudacao("João", "Bom dia")
saudacao("Ana", "Boa noite", 3)
