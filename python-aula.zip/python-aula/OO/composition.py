class Motor:
    def __init__(self, potencia: int) -> None:
        self.potencia: int = potencia

    def ligar(self) -> None:
        print(f"Motor de {self.potencia} cavalos ligado.")

class Carro:
    def __init__(self, marca: str, modelo: str, potencia_motor: int) -> None:
        self.marca: str = marca
        self.modelo: str = modelo
        self.motor: Motor = Motor(potencia_motor)  # Composição

    def ligar_carro(self) -> None:
        print(f"Carro {self.modelo} da marca {self.marca} sendo ligado.")
        self.motor.ligar()

# Testando a composição
meu_carro = Carro("Toyota", "Corolla", 150)
meu_carro.ligar_carro()
