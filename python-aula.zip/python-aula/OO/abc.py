from abc import ABC, abstractmethod

class Veiculo(ABC):
    def __init__(self, marca: str) -> None:
        self.marca: str = marca

    @abstractmethod
    def exibir_informacoes(self) -> None:
        pass

class Carro(Veiculo):
    def __init__(self, marca: str, modelo: str) -> None:
        super().__init__(marca)
        self.modelo: str = modelo

    def exibir_informacoes(self) -> None:
        print(f"Marca do carro: {self.marca}, Modelo: {self.modelo}")

# Testando as classes
carro = Carro("Toyota", "Corolla")
carro.exibir_informacoes()
