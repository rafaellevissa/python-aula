import sys
from jarro import Jarro

class Desenho (object):

	def Desenhar(self,oJarro1,oJarro2):
	    i=0
	    while (i<oJarro1.Get_capacidade()):	    
		if(oJarro1.Get_volume_agua()==oJarro1.Get_capacidade()-i):
		    sys.stdout.write (" |-----|")
		else:
		    if (i+1==oJarro1.Get_capacidade()):
		        sys.stdout.write (" |_____|")
		    else:
		        sys.stdout.write (" |     |")		    		
		if (oJarro1.Get_capacidade()-i<=oJarro2.Get_capacidade()):
		    if(oJarro2.Get_volume_agua()==oJarro1.Get_capacidade()-i):
		        sys.stdout.write ("     |-----|")
		    else:
		        if (i+1==oJarro1.Get_capacidade()):
		            sys.stdout.write ("     |_____|")
		        else:
		            sys.stdout.write ("     |     |")		       
	    	i=i+1
            	print("")

	def __init__(self,oJarro1, oJarro2):
	    i=0
	    while (i<oJarro1.Get_capacidade()):	    
		if(oJarro1.Get_volume_agua()==oJarro1.Get_capacidade()-i):
		    sys.stdout.write (" |-----|")
		else:
		    if (i+1==oJarro1.Get_capacidade()):
		        sys.stdout.write (" |_____|")
		    else:
		        sys.stdout.write (" |     |")		    		
		if (oJarro1.Get_capacidade()-i<=oJarro2.Get_capacidade()):
		    if(oJarro2.Get_volume_agua()==oJarro1.Get_capacidade()-i):
		        sys.stdout.write ("     |-----|")
		    else:
		        if (i+1==oJarro1.Get_capacidade()):
		            sys.stdout.write ("     |_____|")
		        else:
		            sys.stdout.write ("     |     |")		
		print("")
		i=i+1
	    
	    sys.stdout.write("Jarro1: %dL e Jarro2: %dL \n"%(oJarro1.Get_capacidade(),oJarro2.Get_capacidade()))
