import time
from jogador import Jogador
from jarro import Jarro
from desenho import Desenho


print("Jogo dos jarros")
opcao=0
opcao2=0
ponto_best=1000
jogada=0
capacidade_j1=5
capacidade_j2=3
objetivo=4
Jogador1=None
Jogador_best= "PC"
while(opcao!=3):	
	print("------Jogo dos JARROS-----\n")
	print("Melhor Jogador: %s com %d jogadas\n"% (Jogador_best, ponto_best))
	print("Menu:\n")
	print("1- Jogar\n")
	print("2- Opcoes\n")
	print("3- Sair\n")

	opcao=input()

	if(opcao==1):
	    print("Objetivo: encher um dos jarros com %d litros\n"%objetivo)
	    print("Digite o nome do Jogador:\n")
	    Jogador1=input()
	    #criar os objetos
	    player1 = Jogador(Jogador1, 0)
	    j1 = Jarro(capacidade_j1,0)
	    j2 = Jarro(capacidade_j2,0)
	    op=""
	    d=Desenho(j1,j2)
	    jarro_selecionado=None
	    while(j1.Get_volume_agua()!=objetivo and j2.Get_volume_agua()!=objetivo):
		jogada=jogada+1
		print("Qual jarro deseja escolher?\n")
		jarro_selecionado=input()
		print("Qual acao deseja?\n")
		print("(E)ncher, E(s)vaziar, (T)rocar\n")
		op=input()
		if (jarro_selecionado==1):                    
		    if (op=="E" or op=="e"):
		        player1.Encher(j1)
		    elif(op=="s" or op=="S"):
		        player1.Esvaziar(j1)
		    elif(op=="T" or op=="t"):
		        player1.Trocar(j1, j2)
		    else:
		        print("problema ao escolher a opcao")
		    
		elif (jarro_selecionado==2):
		    if (op=="E" or op=="e"):
		        player1.Encher(j2)
		    elif(op=="s" or op=="S"):
		        player1.Esvaziar(j2)
		    elif(op=="T" or op=="t"):
		        player1.Trocar(j2, j1)
		    else:
		        print("problema ao escolher a opcao")		
		d.Desenhar(j1,j2)
		print("Jarro1 com %dL e Jarro2 com %dL \n"%(j1.Get_volume_agua(),j2.Get_volume_agua()))

	    
	    print("Parabens! %s voce venceu com %d jogadas!\n\n"%(Jogador1,jogada))
	    if(jogada<=ponto_best):
		ponto_best=jogada
		Jogador_best=Jogador1	    
	    time.sleep(3)
	elif(opcao==2):
		while (opcao2!=3):
		    print("1- Alterar jarros\n")
		    print("2- Alterar objetivo\n")
		    print("3- Retornar ao menu principal\n")
		    opcao2=input()
		    if (opcao2==1):
			print("Digite o tamanho do jarro maior:\n")
			capacidade_j1=input()
			print("Digite o tamanho do jarro menor:\n")
			capacidade_j2=input()
		    elif (opcao2==2):
			print("Digite o valor de agua que sera o objetivo:\n")
			objetivo=input()	    	
	elif(opcao==3):
		print("Obrigado por jogar!\n")
	else:
		print("opcao invalida!")
	


