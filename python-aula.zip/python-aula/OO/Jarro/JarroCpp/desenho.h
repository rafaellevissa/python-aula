#ifndef DESENHO_H
#define DESENHO_H
#include "jarro.h"

class Desenho
{

public:
    void Desenhar(Jarro oJarro1, Jarro oJarro2);
    Desenho(Jarro oJarro1, Jarro oJarro2);
};

#endif // DESENHO_H
