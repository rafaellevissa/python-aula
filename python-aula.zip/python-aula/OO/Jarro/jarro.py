class Jarro(object) :
	capacidade = None 
	volume_agua = None	
	def __init__(self, capacidade_jarro, volume_agua_jarro) :
		self.capacidade = capacidade_jarro 
		self.volume_agua = volume_agua_jarro
		print("capacidade %d"%self.capacidade)
		print("volume de agua %d"%self.volume_agua)
		pass
	def Get_volume_agua (self) :
		return self.volume_agua
	def Set_volume_agua (self, volume) :
		self.volume_agua=volume 
		pass
	def Get_capacidade (self) :
		return self.capacidade
		
	def Set_capacidade (self, capacidade_jarro) :
		self.capacidade=capacidade_jarro 
		pass

