class Jogador(object) :
	nome = None 
	score = None
	def __init__(self, nome_jogo, score_jogo) :
		self.nome = nome_jogo
		self.score = score_jogo
		pass
	def Get_nome (self) :
		return self.nome		
		
	def Set_nome (self, nome) :
		self.nome=nome 
		pass
	def Get_score (self) :
		return self.score
		
	def Set_score (self, score) :
		self.score=score
		pass
	def Encher (self, oJarro) :
		#codigo de encher jarro 
		oJarro.Set_volume_agua(oJarro.Get_capacidade())		
		pass
	def Esvaziar (self, oJarro) :
		#codigo de esvaziar jarro
		oJarro.Set_volume_agua(0)
		pass
	def Trocar (self, j1, j2):
		#codigo de trocar jarro
		volume1=j1.Get_volume_agua()
		volume2=j2.Get_volume_agua()
		tamanho1=j1.Get_capacidade()
		tamanho2=j2.Get_capacidade()
		if (volume1>0):
		    if(tamanho2-volume2>=volume1):
		        j2.Set_volume_agua(volume2+volume1)
		        j1.Set_volume_agua(0)
		    else:
		        resto1=volume1-(tamanho2-volume2)
		        j1.Set_volume_agua(resto1)
		        j2.Set_volume_agua(tamanho2)
		pass
