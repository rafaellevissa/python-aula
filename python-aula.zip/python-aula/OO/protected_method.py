class Student:
    def __init__(self, name: str) -> None:
        self._name: str = name

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, newname: str) -> None:
        self._name = newname

# Testando a classe
std = Student("Swati")
print(std.name)  # 'Swati'

std.name = 'Dipa'
print(std.name)  # 'Dipa'
print(std._name) # 'Dipa'
