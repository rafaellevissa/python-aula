class Jogador :
	'''(NULL)'''
	def __init__(self) :
		self.Nome = None # string
		self.score = None # int
		pass
	def Get_nome (self) :
		# returns string
		pass
	def Set_nome (self, nome) :
		# returns 
		pass
	def Get_score (self) :
		# returns int
		pass
	def Set_score (self, score) :
		# returns 
		pass
	def Encher (self, oJarro) :
		# returns 
		pass
	def Esvaziar (self, oJarro) :
		# returns 
		pass
	def Trocar (self, j1, j2) :
		# returns 
		pass
class Jarro :
	'''(NULL)'''
	def __init__(self) :
		self.capacidade = None # int
		self.volume_agua = None # int
		pass
	def Get_volume_agua (self) :
		# returns int
		pass
	def Set_volume_agua (self, volume) :
		# returns 
		pass
	def Get_capacidade (self) :
		# returns int
		pass
	def Set_capacidade (self, capacidade) :
		# returns 
		pass
class Jogo :
	'''(NULL)'''
	def __init__(self) :
		self.Nome = None # String
		pass
	def Get_nome (self) :
		# returns String
		pass
	def Set_nome (self, nome_jogo) :
		# returns 
		pass
