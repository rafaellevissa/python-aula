from abc import ABC, abstractmethod

class IVeiculo(ABC):
    @abstractmethod
    def exibir_informacoes(self):
        pass

class Carro(IVeiculo):
    def __init__(self, marca: str, modelo: str):
        self.marca = marca
        self.modelo = modelo

    def exibir_informacoes(self):
        print(f"Marca do carro: {self.marca}, Modelo: {self.modelo}")

# Testando a interface e a classe
carro = Carro("Toyota", "Corolla")
carro.exibir_informacoes()
