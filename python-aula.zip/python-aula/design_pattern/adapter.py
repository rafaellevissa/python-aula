# O padrão Adapter é um padrão de design estrutural que permite 
# a colaboração entre interfaces incompatíveis. Este padrão envolve
#  a criação de um adaptador que converte a interface de uma classe
#   para outra interface que o cliente espera. O adaptador permite
#    que classes com interfaces incompatíveis trabalhem juntas.

class SistemaMetrico:
    def __init__(self, quilometros):
        self.quilometros = quilometros

    def obter_distancia_em_quilometros(self):
        return self.quilometros


class SistemaImperial:
    def __init__(self, milhas):
        self.milhas = milhas

    def obter_distancia_em_milhas(self):
        return self.milhas


class Adapter:
    def __init__(self, sistema, **adapted_methods):
        self._sistema = sistema
        self.__dict__.update(adapted_methods)

    def __getattr__(self, attr):
        return getattr(self._sistema, attr)


# Testando o Adapter
sistema_metrico = SistemaMetrico(10)  # 10 quilômetros
sistema_imperial = SistemaImperial(6.21)  # aproximadamente 10 quilômetros

# Adaptando o sistema imperial para usar a interface do sistema métrico
sistema_imperial_adaptado = Adapter(sistema_imperial, obter_distancia_em_quilometros=sistema_imperial.obter_distancia_em_milhas)

print(f"Distância em quilômetros: {sistema_metrico.obter_distancia_em_quilometros()} km")
print(f"Distância em quilômetros (adaptada de milhas): {sistema_imperial_adaptado.obter_distancia_em_quilometros()} km")


# Neste exemplo:

# SistemaMetrico e SistemaImperial são classes incompatíveis devido às suas interfaces diferentes.
# A classe Adapter converte a interface do SistemaImperial para a interface esperada pelo cliente (SistemaMetrico).
# Quando sistema_imperial_adaptado.obter_distancia_em_quilometros() é chamado, ele internamente chama sistema_imperial.obter_distancia_em_milhas() graças ao mapeamento fornecido no adaptador.