class TodoList:
    """
    Uma classe simples para gerenciar uma lista de tarefas (Todo List).
    """

    def __init__(self):
        """
        Inicializa uma lista de tarefas vazia.
        """
        self.tasks = []

    def add_task(self, task):
        """
        Adiciona uma nova tarefa à lista.
        :param task: str - Descrição da tarefa.
        """
        if not task:
            raise ValueError("A tarefa não pode ser vazia.")
        self.tasks.append(task)

    def remove_task(self, task_index):
        """
        Remove uma tarefa da lista pelo índice.
        :param task_index: int - Índice da tarefa na lista.
        :return: bool - True se a tarefa foi removida com sucesso, False caso contrário.
        """
        if 0 <= task_index < len(self.tasks):
            del self.tasks[task_index]
            return True
        else:
            return False

    def show_tasks(self):
        """
        Exibe todas as tarefas na lista.
        """
        for index, task in enumerate(self.tasks):
            print(f"{index}: {task}")

    def clear_tasks(self):
        """
        Limpa todas as tarefas da lista.
        """
        self.tasks.clear()

# Testando a classe TodoList
todo_list = TodoList()
todo_list.add_task("Ler um capítulo do livro Clean Code")
todo_list.add_task("Escrever um exemplo de código limpo")
todo_list.show_tasks()

# Removendo uma tarefa e exibindo a lista novamente
if todo_list.remove_task(0):
    print("Tarefa removida com sucesso!")
else:
    print("Índice de tarefa inválido.")

todo_list.show_tasks()

# Este exemplo demonstra várias boas práticas de programação:

# Nomes Significativos: As funções e variáveis têm nomes claros e descritivos.
# Funções Pequenas e Focadas: Cada função tem um propósito específico e claro.
# Tratamento de Erros: A função add_task verifica a entrada e lança uma exceção se for inválida.
# Organização Clara: A classe é organizada de forma lógica, com métodos para adicionar, remover, mostrar e limpar tarefas.
# Comentários: Cada método tem um comentário docstring explicando o que faz.