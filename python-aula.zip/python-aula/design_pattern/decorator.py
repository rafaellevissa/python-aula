# O padrão Decorator é um padrão de design estrutural que permite
#  adicionar novos comportamentos a objetos dinamicamente, envolvendo-os
#   em objetos de classes decoradoras. Esse padrão é útil para estender 
#   as funcionalidades de classes de forma flexível e reutilizável.

class Cafe:
    def custo(self):
        return 2

    def descricao(self):
        return "Café"


class DecoratorCafe:
    def __init__(self, cafe):
        self.decorated_cafe = cafe

    def custo(self):
        return self.decorated_cafe.custo()

    def descricao(self):
        return self.decorated_cafe.descricao()


class ComLeite(DecoratorCafe):
    def custo(self):
        return self.decorated_cafe.custo() + 0.5

    def descricao(self):
        return self.decorated_cafe.descricao() + ", com leite"


class ComAçucar(DecoratorCafe):
    def custo(self):
        return self.decorated_cafe.custo() + 0.3

    def descricao(self):
        return self.decorated_cafe.descricao() + ", com açúcar"


# Testando o padrão Decorator
cafe_simples = Cafe()
print(f"Descrição: {cafe_simples.descricao()}. Custo: {cafe_simples.custo()}")

cafe_com_leite = ComLeite(cafe_simples)
print(f"Descrição: {cafe_com_leite.descricao()}. Custo: {cafe_com_leite.custo()}")

cafe_com_leite_e_acucar = ComAçucar(cafe_com_leite)
print(f"Descrição: {cafe_com_leite_e_acucar.descricao()}. Custo: {cafe_com_leite_e_acucar.custo()}")


# Neste exemplo:

# A classe Cafe é a classe original que queremos decorar.
# A classe DecoratorCafe é a classe base para todos os decoradores e mantém uma referência ao objeto Cafe que está sendo decorado.
# ComLeite e ComAçucar são decoradores que estendem a funcionalidade de Cafe adicionando ingredientes e alterando o custo e a descrição.
# O café pode ser decorado com qualquer combinação de decoradores, permitindo uma alta flexibilidade na criação de diferentes variações de café.