Padrões Criacionais: Esses padrões lidam com os mecanismos de criação de objetos, tentando criar objetos de maneira adequada à situação. Os principais padrões criacionais incluem:

Factory Method: Define uma interface para criar um objeto, mas deixa que as subclasses decidam qual classe instanciar.
Abstract Factory: Fornece uma interface para criar famílias de objetos relacionados ou dependentes sem especificar suas classes concretas.
Builder: Separa a construção de um objeto complexo da sua representação, permitindo que o mesmo processo de construção crie diferentes representações.
Prototype: Cria objetos baseando-se em um protótipo de um objeto existente através da clonagem.
Singleton: Garante que uma classe tenha apenas uma instância e fornece um ponto global de acesso a ela.
Padrões Estruturais: Estes padrões lidam com a composição de classes ou objetos. Alguns dos padrões estruturais mais conhecidos são:

Adapter: Permite que interfaces incompatíveis trabalhem em conjunto. O adaptador envolve uma classe existente com uma nova interface.
Composite: Composta objetos em estruturas de árvore para representar hierarquias parte-todo. Permite que clientes tratem objetos individuais e composições de objetos uniformemente.
Proxy: Fornece um substituto ou marcador de posição para outro objeto para controlar o acesso a ele.
Flyweight: Usa compartilhamento para suportar grandes quantidades de objetos de granularidade fina de forma eficiente.
Bridge: Desacopla uma abstração da sua implementação, para que as duas possam variar independentemente.
Decorator: Anexa responsabilidades adicionais a um objeto dinamicamente. Os decoradores fornecem uma alternativa flexível para subclasseamento para estender a funcionalidade.
Padrões Comportamentais: Estes padrões estão preocupados com algoritmos e a designação de responsabilidades entre objetos. Alguns padrões comportamentais incluem:

Strategy: Define uma família de algoritmos, encapsula cada um deles e os torna intercambiáveis. A estratégia permite que o algoritmo varie independentemente dos clientes que o utilizam.
Observer: Define uma dependência um-para-muitos entre objetos, de modo que quando um objeto muda de estado, todos os seus dependentes são notificados e atualizados automaticamente.
Chain of Responsibility: Passa a solicitação ao longo de uma cadeia de manipuladores. Ao receber a solicitação, cada manipulador decide processar a solicitação ou passá-la para o próximo manipulador na cadeia.
Command: Encapsula uma solicitação como um objeto, permitindo parametrizar clientes com diferentes solicitações, enfileirar ou registrar solicitações e implementar operações reversíveis.
State: Permite que um objeto altere seu comportamento quando seu estado interno muda. O objeto parecerá mudar sua classe.
Mediator: Define um objeto que encapsula como um conjunto de objetos interage. O mediador promove o acoplamento fraco, evitando que os objetos se refiram uns aos outros explicitamente, permitindo variar suas interações independentemente.
Iterator: Fornece uma maneira de acessar os elementos de um objeto agregado sequencialmente sem expor sua representação subjacente.
Visitor: Representa uma operação a ser realizada nos elementos de uma estrutura de objeto. O visitante permite que você defina uma nova operação sem alterar as classes dos elementos sobre os quais opera.
Memento: Sem violar o encapsulamento, captura e externaliza o estado interno de um objeto, de modo que o objeto possa ser restaurado para esse estado mais tarde.
Interpreter: Dada uma linguagem, define uma representação para sua gramática, juntamente com um intérprete que usa a representação para interpretar sentenças na linguagem.