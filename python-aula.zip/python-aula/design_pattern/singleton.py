# O padrão de design Singleton garante que uma classe tenha apenas
#  uma instância e fornece um ponto de acesso global a essa instância. 
#  Em Python, Singleton pode ser implementado de várias maneiras, como 
#  usando uma variável de classe ou um decorador. Uma maneira simples e 
#  eficaz de implementar o Singleton em Python é usando a criação de uma
#   instância como parte da definição da classe.

class Singleton:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Singleton, cls).__new__(cls)
            # Inicialize quaisquer variáveis ​​da instância aqui, se necessário
            cls._instance.numero = 0
        return cls._instance

    def incrementar(self):
        self.numero += 1

# Testando o padrão Singleton
objeto1 = Singleton()
objeto2 = Singleton()

print(objeto1 == objeto2)  # Deve ser True, pois são a mesma instância

objeto1.incrementar()
print(objeto2.numero)  # Deve ser 1, mostrando que o estado é compartilhado

objeto2.incrementar()
print(objeto1.numero)  # Deve ser 2, novamente mostrando que o estado é compartilhado

# Neste exemplo, a classe Singleton:

# Usa o método especial __new__ para controlar a criação de instâncias. Este método é chamado antes de __init__ e é responsável por retornar uma nova instância da classe.
# Checa se uma instância já existe. Se não, cria uma nova instância. Se sim, retorna a instância existente.
# Como resultado, qualquer tentativa de criar uma nova instância da classe Singleton resultará na obtenção da mesma instância existente.
