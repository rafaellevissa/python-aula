# O padrão de design Strategy é um padrão de design comportamental que
#  permite definir uma família de algoritmos, encapsular cada um deles 
#  e torná-los intercambiáveis. O Strategy permite que o algoritmo varie
#   independentemente dos clientes que o utilizam.

from abc import ABC, abstractmethod

# Estratégia abstrata
class EstrategiaEnvio(ABC):
    @abstractmethod
    def calcular(self, peso):
        pass

# Estratégia concreta 1
class EnvioPadrao(EstrategiaEnvio):
    def calcular(self, peso):
        return 5 + peso * 0.5

# Estratégia concreta 2
class EnvioExpresso(EstrategiaEnvio):
    def calcular(self, peso):
        return 10 + peso * 0.8

# Estratégia concreta 3
class EnvioInternacional(EstrategiaEnvio):
    def calcular(self, peso):
        return 15 + peso * 1.2

# Contexto
class Pedido:
    def __init__(self, estrategia: EstrategiaEnvio):
        self.estrategia = estrategia

    def calcular_envio(self, peso):
        return self.estrategia.calcular(peso)

# Testando as estratégias
pedido = Pedido(EnvioPadrao())
print(f"Custo de envio (Padrão): {pedido.calcular_envio(10)}")

pedido.estrategia = EnvioExpresso()
print(f"Custo de envio (Expresso): {pedido.calcular_envio(10)}")

pedido.estrategia = EnvioInternacional()
print(f"Custo de envio (Internacional): {pedido.calcular_envio(10)}")

# Neste exemplo:

# EstrategiaEnvio é a interface comum para todas as estratégias de envio.
# EnvioPadrao, EnvioExpresso e EnvioInternacional são estratégias concretas que implementam o método calcular.
# Pedido é o contexto que é configurado com uma estratégia de envio específica. O método calcular_envio calcula o custo do envio com base na estratégia de envio escolhida.
# O cliente (neste caso, o código de teste) pode trocar estratégias de envio dinamicamente no objeto Pedido.
